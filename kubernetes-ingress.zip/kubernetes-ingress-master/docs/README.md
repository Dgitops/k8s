# NGINX Ingress Controller Documentation

* The documentation for the latest stable release is available at https://docs.nginx.com/nginx-ingress-controller/
* The sources of the documentation for the edge version are available at https://github.com/nginxinc/kubernetes-ingress/tree/master/docs-web