# ConfigMap and Annotations

This doc is now available at https://docs.nginx.com/nginx-ingress-controller/configuration/global-configuration/configmap-resource/ (for ConfigMap) and https://docs.nginx.com/nginx-ingress-controller/configuration/ingress-resources/advanced-configuration-with-annotations/ (for Annotations).